# Estrutura de Projeto - Exercício 1 - Parte 2

Este diretório contém a estrutura básica de um projeto web, organizada para facilitar o desenvolvimento e a manutenção. Abaixo, é detalhada a função de cada pasta e arquivo:

## Pastas

*   **css/**: Esta pasta é destinada a armazenar todos os arquivos de folhas de estilo (CSS - Cascading Style Sheets) do projeto. O CSS é responsável por definir a apresentação visual dos elementos HTML, como cores, fontes, layouts e responsividade.

*   **js/**: Esta pasta contém os arquivos de script JavaScript. O JavaScript é uma linguagem de programação que permite adicionar interatividade e dinamismo às páginas web, manipulando o DOM (Document Object Model), realizando requisições assíncronas e implementando lógicas complexas.

*   **img/**: Esta pasta é utilizada para armazenar todas as imagens e outros recursos visuais (ícones, logotipos, etc.) que serão utilizados no projeto. A organização das imagens em um diretório separado facilita a gestão e o carregamento dos ativos visuais.

## Arquivos

*   **index.html**: Este é o arquivo principal do projeto web. Ele contém a estrutura HTML (HyperText Markup Language) da página, definindo o conteúdo e a organização dos elementos que serão exibidos no navegador. Geralmente, é a primeira página a ser carregada em um site.

*   **css/style.css**: Este arquivo é a folha de estilo principal do projeto. Nele, são definidas as regras de estilo CSS que serão aplicadas ao `index.html` e, potencialmente, a outras páginas HTML. É aqui que se controla a aparência visual do site.

*   **js/script.js**: Este arquivo contém os scripts JavaScript do projeto. Nele, são implementadas as funcionalidades interativas e dinâmicas da página, como validação de formulários, animações, manipulação de eventos e comunicação com APIs.

*   **README.md**: Este arquivo, escrito em Markdown, serve como um guia e documentação do projeto. Ele fornece informações essenciais sobre a estrutura, como usar o projeto, dependências, instruções de instalação e qualquer outra informação relevante para desenvolvedores ou usuários. É o ponto de partida para entender o projeto.
